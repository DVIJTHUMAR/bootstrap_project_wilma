# Reforma 

Reforma is a bespoke typeface designed for the Universidad Nacional de Córdoba. The UNC commissioned PampaType to create this typeface as part of the celebrations for the centenary of the University Reform, occurred in this house in 1918. Following Argentina’s national education policy, libre and free, the typeface Reforma is freely available for anyone, under the Creative Commons license BY-ND 4.0 International. This full license is available at: https://creativecommons.org/licenses/by-nd/4.0/

© Copyright 2018 by the Universidad Nacional de Córdoba [AR]. Designed by Alejandro Lo Celso. Programmed by Guido Ferreyra. PampaType font foundry.
http://pampatype.com.

# Changelog

Version 1.000 (Roman and Italic) created 24/04/2018

    First release

Versión 1.001 (Roman) creada 07/06/2018

    Bug fix on dieresis 


